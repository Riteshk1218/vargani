from django.apps import AppConfig


class PeopleConfig(AppConfig):
    name = "apps.people"
    label = "people"
